# SAMI — Design Assets

Frontend-ready assets for **SAMI — Smart Automated Markdown Interpreter**.

## Folder structure

```
sami-assets/
├── README.md              ← You are here
├── icon/
│   ├── sami-icon.svg      ← Full icon (with fold detail), use at ≥48px
│   ├── sami-icon-simple.svg ← Simplified (M only), use at ≤32px
│   ├── sami-icon.ico      ← Windows .ico (256, 48, 32, 16 embedded)
│   ├── sami-icon-512.png
│   ├── sami-icon-256.png
│   ├── sami-icon-128.png
│   ├── sami-icon-96.png
│   ├── sami-icon-64.png
│   ├── sami-icon-48.png
│   ├── sami-icon-32.png   ← uses simple variant
│   ├── sami-icon-24.png   ← uses simple variant
│   └── sami-icon-16.png   ← uses simple variant
├── palette/
│   ├── tokens.json        ← Full design tokens (colors, type, spacing, elevation, components)
│   └── variables.css      ← CSS custom properties, light/dark via [data-theme] or prefers-color-scheme
├── ui/
│   └── i18n.json          ← All UI strings in English and Spanish with {placeholder} interpolation
└── fonts/                 ← (empty — load from Google Fonts, URL in tokens.json)
```

## Icon usage

| Context                  | File                    | Notes                           |
|--------------------------|-------------------------|---------------------------------|
| Window titlebar          | `sami-icon-18.png` (resize from 24) or inline SVG | Small, needs simple variant |
| Windows taskbar          | `sami-icon.ico`         | Multi-res, auto-selects         |
| Linux .desktop           | `sami-icon-128.png`     | Or SVG for scalable             |
| macOS app bundle         | Generate .icns from 512 | Use full variant with fold      |
| Installer / about dialog | `sami-icon-256.png`     | Full variant                    |
| Favicon                  | `sami-icon-32.png`      | Simple variant                  |

**Key rule:** At 48px and above, use `sami-icon.svg` (shows fold detail). At 32px and below, use `sami-icon-simple.svg` (M glyph only — the fold becomes noise at small sizes).

## Color system

### Brand
| Token             | Light         | Dark          |
|-------------------|---------------|---------------|
| `--sami-brand`    | `#7B6DAF`     | `#7B6DAF`     |
| `--sami-accent`   | `#7B6DAF`     | `#9B8DC8`     |

The accent lightens in dark mode for readability. The brand color stays the same everywhere (icon, splash, marketing).

### Surfaces
| Token               | Light       | Dark        |
|----------------------|-------------|-------------|
| `--sami-bg-window`   | `#F0F0F0`   | `#1A1A1A`   |
| `--sami-bg-surface`  | `#FFFFFF`   | `#1E1E1E`   |
| `--sami-bg-raised`   | `#FAFAFA`   | `#252525`   |
| `--sami-bg-inset`    | `#F5F5F5`   | `#2A2A2A`   |

### Semantic
| Token              | Value       | Use                              |
|--------------------|-------------|----------------------------------|
| `--sami-success`   | `#62C554`   | Completed files, done badges     |
| `--sami-warning`   | `#E5A63B`   | Warnings, attention triangles    |
| `--sami-error`     | `#E24B4A`   | Errors, cancel, PDF icon stroke  |
| `--sami-info`      | `#4A9FD9`   | Info banners                     |

## Typography

| Role     | Family          | Weights used | Where                              |
|----------|-----------------|--------------|--------------------------------------|
| Body     | Inter           | 400, 500, 600 | All UI text                         |
| Heading  | Space Grotesk   | 500, 600, 700 | Section headers, about/splash       |
| Mono     | JetBrains Mono  | 400, 500       | Markdown preview pane               |

Load via Google Fonts (URL in `tokens.json` and `variables.css`).

## Themes

Import `variables.css`. Light is default. Set `data-theme="dark"` on `<html>` to force dark. Without the attribute, it follows `prefers-color-scheme`.

## i18n

`ui/i18n.json` has every UI string in `en` and `es`. Placeholders use `{name}` syntax. The app title stays in English in both locales (it's a product name).

## App states

The design has three states, each in light and dark:

1. **Before conversion** — File list with checkboxes, drop zone, conversion mode selector (Balanced/Fast/Thorough), Convert button
2. **During conversion** — Active file with stage name + progress bar, waiting files queued below, overall progress bar, Cancel button, explanation of sequential processing
3. **After conversion** — Sidebar file list with status icons, warning banner in plain language with "Show technical details" link, split-pane preview (Original PDF | Converted Markdown)

## Component dimensions

| Component      | Value   |
|----------------|---------|
| Window chrome  | 36px    |
| Toolbar        | 48px    |
| Button height  | 32px    |
| Button radius  | 6px     |
| Sidebar width  | 300px   |
| Progress bar   | 6-8px   |
| Border radius  | 6-8px   |
| Icon radius    | 28px    |
